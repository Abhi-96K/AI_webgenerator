
    function openModal(modalId) {
        document.getElementById(modalId).style.display = "block";
    }
    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = "none";
    }

    function handleLogin() {
        const email = document.getElementById("loginEmail").value;
        const password = document.getElementById("loginPassword").value;
        // Add your login logic here
        alert(`Login attempted with Email: ${email}`);
        closeModal('loginModal');
    }

    function handleRegister() {
        const email = document.getElementById("registerEmail").value;
        const password = document.getElementById("registerPassword").value;
        // Add your registration logic here
        alert(`Registration attempted with Email: ${email}`);
        closeModal('registerModal');
    }
