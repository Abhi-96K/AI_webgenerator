
        document.getElementById('registerForm').addEventListener('submit', function(event) {
            event.preventDefault();
            alert('Registration Successful!');
            // Add your registration logic here
        });

        document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault();
            alert('Login Successful!');
            // Add your login logic here
        });

        function initMap() {
            const map = new google.maps.Map(document.getElementById("map"), {
                center: { lat: -34.397, lng: 150.644 },
                zoom: 8,
            });

            map.addListener("click", (event) => {
                const lat = event.latLng.lat();
                const lng = event.latLng.lng();
                alert(`You clicked at latitude: ${lat}, longitude: ${lng}`);
            });
        }
    