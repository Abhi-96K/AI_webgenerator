
    function showSection(section) {
        const sections = ['home', 'login', 'register', 'map'];
        sections.forEach(s => {
            document.getElementById(s).style.display = (s === section) ? 'block' : 'none';
        });
        if (section === 'login' || section === 'register') {
            document.querySelector('.login-form').style.display = (section === 'login') ? 'block' : 'none';
            document.querySelector('.registration-form').style.display = (section === 'register') ? 'block' : 'none';
        } else {
            document.querySelector('.login-form').style.display = 'none';
            document.querySelector('.registration-form').style.display = 'none';
        }
    }

    function login() {
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        alert('Login attempted with Email: ' + email);
    }

    function register() {
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        if (password === confirmPassword) {
            alert('Registration successful for Email: ' + email);
        } else {
            alert('Passwords do not match!');
        }
    }

    function initMap() {
        const location = { lat: -34.397, lng: 150.644 };
        const map = new google.maps.Map(document.getElementById('map'), {
            zoom: 8,
            center: location
        });
        const marker = new google.maps.Marker({
            position: location,
            map: map
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        showSection('home');
        const script = document.createElement('script');
        script.src = 'https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&callback=initMap';
        script.defer = true;
        document.body.appendChild(script);
    });
